# CodeDojo Daily — DailyDebug Derby

A hackathon-ready MVP based on the uploaded problem brief.

## Features
- Daily challenge hub with problem statement, examples, constraints, tags and difficulty
- Search and filter by topic and difficulty
- In-browser JavaScript/Python code workspace (the demo runner evaluates JavaScript snippets against sample tests)
- Team creation and roster display
- Team leaderboard with solve counts and streak bonus
- Daily streak calendar
- Demo data for coding challenges and teams

## Run locally
Requirements: Node.js 18+

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal. The Express API runs at `http://localhost:4000`.

For a production build:
```bash
npm run build
npm start
```

## Important prototype note
The browser runner is a hackathon demonstration, not a secure execution environment. It evaluates JavaScript in a Web Worker with a timeout and does not execute Python. Do not use it to run untrusted code in production. A production system should use isolated server-side containers and resource limits.

## Project structure
- `client/` React + TypeScript UI
- `server/` Express + TypeScript API
- `data/` JSON seed data
